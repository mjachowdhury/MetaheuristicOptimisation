# -*- coding: utf-8 -*-
"""
Created on Sat Nov  7 12:09:33 2020

@author: Mohammed Alom
""" 
 
"""
Basic TSP Example
file: Individual.py
"""

import random
import math
import numpy as np
from enum import Enum


class Initial_Solution(Enum):
    RANDOM=1,
    HEURISTIC=2
    
class Individual:
    def __init__(self, _size, _data, _initialSolutionType):
        """
        Parameters and general variables
        """
        self.fitness    = 0
        self.genes      = []
        self.genSize    = _size
        self.data       = _data
        self.initialSolutionType = _initialSolutionType
        self.genes = list(self.data.keys())

        if _initialSolutionType == Initial_Solution.HEURISTIC:
            self.nearestNeighbourGeneration()
        else:
            self.randomGeneration()
            self.computeFitness()

    def __str__(self):
        return str(self.getFitness())   
    """
    Generating randomly all the cities and shuffle the cities 
    and repet the steps size of the population
    """
    def randomGeneration(self):

        for i in range(0, self.genSize):
            n1 = random.randint(0, self.genSize - 1)
            n2 = random.randint(0, self.genSize - 1)
            temp = self.genes[n2]
            self.genes[n2] = self.genes[n1]
            self.genes[n1] = temp
    """
    Generating list of all the cities and randomly selecting the city
    calculating the path of hte cost the append the cities with shortest path cost
    repet the steps as size of the population.
    """
    def nearestNeighbourGeneration(self):
        totalCities = []
        currentCity = random.randint(0, self.genSize - 1)
        i = 0
        cityVisited = []
        totalCities.append(currentCity)
        cityVisited.append(currentCity)
        shortestDistanceCity = None
        nearestCity = None

        while len(totalCities) < self.genSize:
            if i not in cityVisited:
                distance = self.euclideanDistance(self.genes[currentCity], self.genes[i])
                if shortestDistanceCity is None or distance < shortestDistanceCity:
                    shortestDistanceCity = distance
                    nearestCity = i

            if i == self.genSize - 1:
                totalCities.append(nearestCity)
                self.fitness += shortestDistanceCity
                currentCity = nearestCity
                cityVisited.append(nearestCity)
                i = 0
                shortestDistanceCity = None
                nearestCity = None
            else:
                i += 1
        self.genes = np.array(self.genes)[totalCities]


    def setGene(self, genes):
        """
        Updating current choromosome
        """
        self.genes = []
        for gene_i in genes:
            self.genes.append(gene_i)

    def copy(self):
        """
        Creating a new individual
        """
        ind = Individual(self.genSize, self.data, self.initialSolutionType)
        for i in range(0, self.genSize):
            ind.genes[i] = self.genes[i]
        ind.fitness = self.getFitness()
        return ind

    def euclideanDistance(self, c1, c2):
        """
        Distance between two cities
        """
        d1 = self.data[c1]
        d2 = self.data[c2]
        return math.sqrt( (d1[0]-d2[0])**2 + (d1[1]-d2[1])**2 )

    def getFitness(self):
        return self.fitness

    def computeFitness(self):
        """
        Computing the cost or fitness of the individual
        """
        self.fitness    = self.euclideanDistance(self.genes[0], self.genes[len(self.genes)-1])
        for i in range(0, self.genSize-1):
            self.fitness += self.euclideanDistance(self.genes[i], self.genes[i+1])

