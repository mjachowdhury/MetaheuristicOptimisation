# -*- coding: utf-8 -*-
"""
Created on Sat Nov  7 12:09:33 2020

@author: Mohammed Alom
""" 
 
from Individual import *
import sys 
import copy
import numpy as np
import random
from enum import Enum
 

# R00144214
myStudentNum = 144214 # Replace 12345 with your student number
random.seed(myStudentNum)


class BasicTSP:
    def __init__(self, _fName, _popSize, _mutationRate, _maxIterations, _configuration): 
        """
        Parameters and general variables
        """
        self.population     = []
        self.newpopulation  = []
        self.matingPool     = []
        self.best           = None
        self.popSize        = _popSize
        self.genSize        = None
        self.mutationRate   = _mutationRate
        self.maxIterations  = _maxIterations
        self.iteration      = 0
        self.fName          = _fName
        self.data           = {}      
        #self.counter = 0
        """
        config setup
        """
        self.selectionType  = _configuration.selection
        self.initialSolutionType = _configuration.initial_solution
        self.crossoverType = _configuration.crossover
        self.mutationType = _configuration.mutation         
        self.readInstance()
        self.initPopulation()

    def __str__(self):
        """
        String representation outputs
        """
        return "\nTSP FILE NAME : " + self.fName \
               + "\nPOPULATION SIZE : " + str(self.popSize) \
               + "\nMUTATION RATE : " + str(self.mutationRate) \
               + "\nTOTAL ITERATION : " + str(self.maxIterations)

    def readInstance(self):
        """
        Reading an instance from fName
        """
        file = open(self.fName, 'r')
        self.genSize = int(file.readline())
        self.data = {}
        for line in file:
            (id, x, y) = line.split()
            self.data[int(id)] = (int(x), int(y))
        file.close()

    def initPopulation(self):
        """
        Creating random individuals in the population
        """
        for i in range(0, self.popSize):
            individual = Individual(self.genSize, self.data, self.initialSolutionType)
            #individual.computeFitness()
            self.population.append(individual)
            
        self.best = self.population[0].copy()
#        for ind_i in self.population:
#            if self.best.getFitness() > ind_i.getFitness():
#                self.best = ind_i.copy()
        print ("BEST INITIAL SOLUATION: ",self.best.getFitness())


    def updateBest(self, candidate):
        if self.best.getFitness() == None or candidate.getFitness() < self.best.getFitness():
            self.best = candidate.copy()
            print ("ITERATION : ", self.iteration, "BEST : ", self.best.getFitness())

    def randomSelection(self):
        """
        Random (uniform) selection of two individuals
        """
        indA = self.matingPool[ random.randint(0, self.popSize-1) ]
        indB = self.matingPool[ random.randint(0, self.popSize-1) ]
        return [indA, indB]
    
    def binaryTournamentSelection(self):
        """
        Code Taken from the lecture notes
        """
        self.matingPool = []
        for ind_i in self.population:
            elementsInPool = int(ind_i.getFitness() * 100)
            for i in range(0, elementsInPool):
                self.matingPool.append(ind_i)
        for ind_i in range(0, len(self.population)):
            indexPartnerA = random.randint(0, len(self.matingPool) - 1)
            indexPartnerB = random.randint(0, len(self.matingPool) - 1)          
            partnerA = self.matingPool[indexPartnerA]
            partnerB = self.matingPool[indexPartnerB]
            child = self.crossover(partnerA, partnerB)
            self.mutate(child)
            child.computeFitness(self.target)          
            self.population[ind_i] = child
            if child.getFitness() > self.best.getFitness():
                self.best = child        
 
        
    def uniformOrderBasedCrossover(self, indA, indB):
        """
        Selecting smallest one from both individuals
        """
        smallValue = min(len(indA.genes), len(indB.genes))
        """
        Binary Template
        """
        binaryTemplate = [random.randint(0, 1) for _ in range(smallValue)]
        empty_binay_slot = []
        """
        Finding empty sloat and adding to the binary slot
        """
        for indx, value in enumerate(binaryTemplate):
            if value == 0:
                empty_binay_slot.append(indx)
        """
        Finding genes 0 th position inside the binary template
        """
        ChildA = np.array(indA.genes)[empty_binay_slot]
        ChildB = np.array(indB.genes)[empty_binay_slot]
        """
        Sorting genes
        """
        ChildA = self.sortItems(ChildA, indB.genes)
        ChildB = self.sortItems(ChildB, indA.genes)
        """
        Replacing genes
        """
        i = 0
        for index in empty_binay_slot:
            indA.genes[index] = ChildA[i]
            indB.genes[index] = ChildB[i]
            i += 1

        return indA, indB
    
    def order1Crossover(self, parent1, parent2):
        """
        Order 1 crossover implementation
        """    
        child = [None] * len(parent1)
        itemsNotAdded = None
        """
        Randomly choose two crosspoint
        """
        geneA, geneB = random.choices(range(len(parent1)),k=2)   
        startGenePoint = min(geneA, geneB)
        endGenePoint = max(geneA, geneB)
        parent2Index = endGenePoint
        copyParentIndex = endGenePoint
        """
        Copy part of parent1 to child 
        """
        child[startGenePoint:endGenePoint] = parent1[startGenePoint:endGenePoint]
        """
        Copy form parent2 over child
        """
        itemsNotAdded = [item for item in parent2 if item not in child]   
        for i in range(0, len(itemsNotAdded)):
            if parent2[parent2Index] not in child:
                if child[copyParentIndex] != None:
                    while child[copyParentIndex] != None:
                        copyParentIndex += 1  
                        if copyParentIndex >= len(child):
                            copyParentIndex = 0   
            else:
                while parent2[parent2Index] in child:
                    parent2Index += 1    
                    if parent2Index >= len(parent2):
                        parent2Index = 0   
            child[copyParentIndex] = parent2[parent2Index]      
            parent2Index += 1
            copyParentIndex += 1   
            if parent2Index >= len(parent2):
                parent2Index = 0    
            if copyParentIndex >= len(child):
                copyParentIndex = 0    
        return child
    
 
    def scrambleMutation(self, ind):
        """
        Scramble Mutation implementation
        """
        if not self.doMutation():
            return

        startIndex = random.randint(0, self.genSize-2)
        endIndex = random.randint(startIndex + 1, self.genSize-1) 
        sliceOfArray = ind.genes[startIndex:endIndex]
        random.shuffle(sliceOfArray)
        ind.genes[startIndex:endIndex] = sliceOfArray
        ind.computeFitness()
        self.updateBest(ind)

        pass
       
    def inversionMutation(self, ind):
        """
        Your Inversion Mutation implementation
        """
        indexA, indexB = self.chooseRandomGene()
        geneRange = [indexA, indexB]
        geneRange.sort()
        ind.genes[geneRange[0]:geneRange[1]] = ind.genes[geneRange[0]:geneRange[1]][::-1]
        ind.computeFitness()
        self.updateBest(ind)

    def crossover(self, indA, indB):
        """
        Executes a 1 order crossover and returns a new individual
        """
#        midP=int(self.genSize/2)
#        cgenes = indA.genes[0:midP]
#        for i in range(0, self.genSize):
#            if indB.genes[i] not in cgenes:
#                cgenes.append(indB.genes[i])
#        child = Individual(self.genSize, self.data, cgenes)
#        return child
        
        child = []
        temp = {}
        indexA = random.randint(0, self.genSize-1)
        indexB = random.randint(0, self.genSize-1)

        for i in range(0, self.genSize):
            if i >= min(indexA, indexB) and i <= max(indexA, indexB):
                temp[indA.genes[i]] = False
            else:
                temp[indA.genes[i]] = True
        secondary = []
        for i in range(0, self.genSize):
            if not temp[indB.genes[i]]:
                child.append(indB.genes[i])
            else:
                secondary.append(indB.genes[i])
        child += secondary
        child_individual = indB.copy()
        child_individual.setGene(child)
        return child_individual

    def updateMatingPool(self):
        """
        Updating the mating pool before creating a new generation
        """
        self.matingPool = []
        if self.selectionType.BINARY_TOURNAMENT_SELECTION:            
            self.binaryTournamentSelection()
        else:
            for ind_i in self.population:
                self.matingPool.append( ind_i.copy() )

    def newGeneration(self):
        """
        Creating a new generation
        1. Selection
        2. Crossover
        3. Mutation
        """
        for i in range(0, self.popSize):
            """
            Depending of your experiment you need to use the most suitable algorithms for:
            1. Select two candidates
            2. Apply Crossover
            3. Apply Mutation
            """
            indA =self.binaryTournamentSelection()
            indB =self.binaryTournamentSelection()
            
            #indA, indB = self.randomSelection()
            childA, childB = None, None             

            if self.crossoverType == Crossover.ORDER_ONE_CROSS_OVER:
                childA, childB = self.order1Crossover(indA, indB)
            elif self.crossoverType == Crossover.UNIFORM_CROSS_OVER:
                childA, childB = self.uniformOrderBasedCrossover(indA, indB)
            if self.mutationType == Mutation.INVERSION_MUTATION:
                self.inversionMutation(childA)
                self.inversionMutation(childB)
            elif self.mutationType == Mutation.SCRAMBLE_MUTATION:
                self.scrambleMutation(childA)
                self.scrambleMutation(childB)

    def GAStep(self):
        """
        One step in the GA main algorithm
        1. Updating mating pool with current population
        2. Creating a new Generation
        """
        self.updateMatingPool()
        self.newGeneration()

 
    def search(self):
        """
        General search template.
        Iterates for a given number of steps
        """
        self.iteration = 0
        while self.iteration < self.maxIterations and self.best.getFitness()<500:
            self.GAStep()
            self.iteration += 1
            #self.counter+=1
        #print ("Total iterations: ",self.iteration)
        print ("BEST SOLUTION: ", self.best.getFitness())
    
    def sortItems(self, childItems, parent):
        childAMap = {}
        for gene in childItems:
            childAMap[int(np.where(parent==gene)[0][0])] = gene
        childAMap = dict(sorted(childAMap.items()))
        return list(childAMap.values())
        
    def doMutation(self):
        return random.random() > self.mutationRate

    def chooseRandomGene(self):
        if random.random() > self.mutationRate:
            self.chooseRandomGene()
        indexA = random.randint(0, self.genSize-1)
        indexB = random.randint(0, self.genSize-1)
        return indexA, indexB    
        
class Initial_Solution(Enum):
    RANDOM=1,
    HEURISTIC=2
    
class Selection(Enum):
    RANDOM=1,
    BINARY_TOURNAMENT_SELECTION=2
    
class Crossover(Enum):
    UNIFORM_CROSS_OVER=1,
    ORDER_ONE_CROSS_OVER=2 
    
class Mutation(Enum):
    INVERSION_MUTATION=1,
    SCRAMBLE_MUTATION=2

class GA_Config:
    def __init__(self, configName, selectionType, initialSolution, crossoverType, mutationType ):
        self.name = "CONFIG NUMBER : " + configName
        self.selection =selectionType
        self.initial_solution = initialSolution
        self.crossover = crossoverType
        self.mutation =mutationType

    def __str__(self):
        return self.name + "\nSELECTION TYPE : " + str(self.selection) \
               + "\nINITIAL SOLUTION TYPEe : " + str(self.initial_solution) \
               + "\nCROSSOVER TYPE : " + str(self.crossover) \
               + "\nMUTATION TYPE: " + str(self.mutation)

if len(sys.argv) < 5:
    print ("Error - Incorrect input")
    print ("Expecting python BasicTSP.py [instance], population size, mutation rate, configuration number (1 of 8) ")
    sys.exit(0)
"""
TSP files for test = ["TSPdata\inst-4.tsp", "TSPdata\inst-6.tsp", "TSPdata\inst-16.tsp"]
"""
problem_file = sys.argv[1]
"""
Select population size= [100, 200, 300, 400]
""" 
population_size = int(sys.argv[2])
"""
Select mutation rates = [0.1, 0.2, 0.3, 0.4]
"""
mutation_rate = float(sys.argv[3])
"""
Select test congif [1-6]
"""
config_no = int(sys.argv[4])-1
"""
Set number of times to run config
"""
number_of_test_iterations = 5
"""
Set number of iteration
"""
no_of_iterations = 500

"""
Test configuration setup
""" 
configurations = [
    GA_Config("1", Selection.BINARY_TOURNAMENT_SELECTION, 
                   Initial_Solution.RANDOM, 
                   Crossover.ORDER_ONE_CROSS_OVER,
                   Mutation.INVERSION_MUTATION),
              
    GA_Config("2", Selection.BINARY_TOURNAMENT_SELECTION, 
                   Initial_Solution.RANDOM, 
                   Crossover.UNIFORM_CROSS_OVER, 
                   Mutation.SCRAMBLE_MUTATION),
    
    
    GA_Config("3", Selection.BINARY_TOURNAMENT_SELECTION, 
                   Initial_Solution.RANDOM, 
                   Crossover.ORDER_ONE_CROSS_OVER, 
                   Mutation.SCRAMBLE_MUTATION),
              
    GA_Config("4", Selection.BINARY_TOURNAMENT_SELECTION, 
                   Initial_Solution.RANDOM, 
                   Crossover.UNIFORM_CROSS_OVER, 
                   Mutation.INVERSION_MUTATION),
    
    GA_Config("5", Selection.BINARY_TOURNAMENT_SELECTION, 
                   Initial_Solution.HEURISTIC,
                   Crossover.ORDER_ONE_CROSS_OVER, 
                   Mutation.SCRAMBLE_MUTATION),
    
    GA_Config("6", Selection.BINARY_TOURNAMENT_SELECTION, 
                   Initial_Solution.HEURISTIC,
                   Crossover.UNIFORM_CROSS_OVER, 
                   Mutation.INVERSION_MUTATION),
                  ]

config = configurations[config_no]

for test in range(0, number_of_test_iterations):
    print("NUMBER OF RUN: " + str(test + 1))
    ga = BasicTSP(problem_file, population_size, mutation_rate, no_of_iterations, config)
    print(ga)
    print(config)
    ga.search()
 
