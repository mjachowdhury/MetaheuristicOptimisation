# -*- coding: utf-8 -*-
"""
Created on Fri Dec 18 18:33:01 2020

@author: mohammed alom
reference : Would like acknowledge this program is created with the help and ideas of
multiple sources- majorityof the code is from Dr. Diarmuid Grimes, greekforgreek website, stackoveflow.
Both queen.py and HillClimbing.py files  modified. 
"""

from statistics import mean, stdev
from random import randrange
from copy import deepcopy
from random import choice
import random

N = int(input('ENTER THE NUMBER OF QUEENS :'));

studentNum = 144214
random.seed(studentNum)

class Queens:
    instance_counter = 0

    def __init__(self, queen_positions=None, queen_num=N, parent=None, path_cost=0, f_cost=0, side_length=N):
        
        self.side_length = side_length
        
        if queen_positions is None:
            self.queen_num = queen_num
            self.queen_positions = frozenset(self.generateRandomState())
        else:
            self.queen_positions = frozenset(queen_positions)
            self.queen_num = len(self.queen_positions)

        self.path_cost = 0
        self.f_cost = f_cost
        self.parent = parent
        self.id = Queens.instance_counter
        Queens.instance_counter += 1

     
    def generateRandomState(self):
        open_columns = list(range(self.side_length))
        queen_positions = [(open_columns.pop(randrange(len(open_columns))), randrange(self.side_length)) for _ in
                           range(self.queen_num)]
        return queen_positions

    def getHeuristicCost(self):
        children = []
        parent_queen_positions = list(self.queen_positions)
        for queen_index, queen in enumerate(parent_queen_positions):
            new_positions = [(queen[0], row) for row in range(self.side_length) if row != queen[1]]
            for new_position in new_positions:
                queen_positions = deepcopy(parent_queen_positions)
                queen_positions[queen_index] = new_position
                children.append(Queens(queen_positions))
        return children

    def getHeuristicCostQueen(self):

        def range_between(a, b):
            if a > b:
                return range(a - 1, b, -1)
            elif a < b:
                return range(a + 1, b)
            else:
                return [a]

        def zip_repeat(a, b):
            if len(a) == 1:
                a = a * len(b)
            elif len(b) == 1:
                b = b * len(a)
            return zip(a, b)
        
        def points_between(a, b):
            return zip_repeat(list(range_between(a[0], b[0])), list(range_between(a[1], b[1])))

        def is_attacking(queens, a, b):
            if (a[0] == b[0]) or (a[1] == b[1]) or (abs(a[0] - b[0]) == abs(a[1] - b[1])):
                for between in points_between(a, b):
                    if between in queens:
                        return False
                return True
            else:
                return False

        attacking_pairs = []
        queen_positions = list(self.queen_positions)
        left_to_check = deepcopy(queen_positions)
       
        while left_to_check:
            a = left_to_check.pop()
            
            for b in left_to_check:
                
                if is_attacking(queen_positions, a, b):
                    attacking_pairs.append([a, b])
         
        return len(attacking_pairs)

    def __str__(self):
        return '\n'.join([' '.join(['.' if (col, row) not in self.queen_positions else 'Q' for col in range(
            self.side_length)]) for row in range(self.side_length)])

 
class QueensProblem:

    def __init__(self, start_state=None):
        if not start_state:
            start_state = Queens()
        self.start_state = start_state

    def goal_test(self, state):
        return state.getHeuristicCostQueen() == 0

    def Calculate_heuristic(self, state):
        return state.getHeuristicCostQueen()
 

 
def HillClimbing(problem, allow_sideways=False, max_sideways=100):
    
    def solveMaxMin(node, problem):
        children = node.getHeuristicCost()
        children_cost = [problem.Calculate_heuristic(child) for child in children]
        min_cost = min(children_cost)

        best_child = choice([child for child_index, child in enumerate(children) if children_cost[
            child_index] == min_cost])
        return best_child

    node = problem.start_state
    node_cost = problem.Calculate_heuristic(node)
    path = []
    sideways_moves = 0

    while True:
        path.append(node)
        best_child = solveMaxMin(node, problem)
        # print("\n" + str(best_child))
        best_child_cost = problem.Calculate_heuristic(best_child)

        if best_child_cost > node_cost:
            break
        elif best_child_cost == node_cost:
            if not allow_sideways or sideways_moves == max_sideways:
                break
            else:
                sideways_moves += 1
        else:
            sideways_moves = 0
        node = best_child
        node_cost = best_child_cost

    return {'outcome': 'success' if problem.goal_test(node) else 'failure',
            'solution': path,
            'problem': problem}


def random_restart_hill_climb(random_problem_generator, num_restarts=100, allow_sideways=False, max_sideways=100):
    path = []
    nRestart = 0
    while 1:
        result = HillClimbing(random_problem_generator(), allow_sideways=allow_sideways,
                                            max_sideways=max_sideways)
        nRestart += 1
        path += result['solution']
        if result['outcome'] == 'success':
            break
    result['solution'] = path
    result['NoRestarts'] = nRestart
    return result

def calculate_avg_pathcost(result_list, key):
    results = [result[key] for result in result_list]
    if len(result_list) == 1:
        return {'mean': result_list[0][key], 'sd': 0}
    elif not result_list:
        return {'mean': 0, 'sd': 0}
    return {'mean': mean(results), 'sd': stdev(results)}

# Print results for Steepest Ascent hill climbing algo
def print_results(results):
    title_col_width = 30
    data_col_width = 15

    def print_data_row(row_title, data_string, data_func, results):
        nonlocal title_col_width, data_col_width
        row = (row_title + '\t').rjust(title_col_width)
        result_groups = iter(results)
        next(result_groups)
        for result_group in result_groups:
            row += data_string.format(**data_func(result_group)).ljust(data_col_width)
        print(row)

    # Printing four search sequences
    def print_search_sequence(results):
        print('\nSearch sequence path:')
        i = 1
        for result in results[0]:
            print('Search sequence ', i)
            for sol_path in result['solution']:
                seqs = sol_path.queen_positions
                print([list(x) for x in seqs])
            i += 1
            if i > 4:  # break when 4 sequences are printed
                break

    num_iterations = len(results[0])

    # Print Header
    print('\t\t'.rjust(title_col_width) +
          'SUCCESSES'.ljust(data_col_width) +
          'FAILURE'.ljust(data_col_width))

    # Print success and failure percentages
    print_data_row('\n\tSUCCESS AND FAILURE RATE :',
                   '{percent:.1%}',
                   lambda x: {'percent': len(x) / num_iterations},
                   results)

    # Print Average number of steps
    print_data_row('AVERAGE NUMBER OF STEPS :',
                   '{mean:.0f}',
                   lambda x: calculate_avg_pathcost(x, 'path_length'),
                   results)

    # Print search sequence for steepest ascent hill-climbing algorithms
    #print_search_sequence(results)


# Print results for Random-restart hill climbing algo
def printSolution_random_restartResult(results, Avg_restarts):
    title_col_width = 30
    data_col_width = 15

    def print_data_row(row_title, data_string, data_func, results):
        nonlocal title_col_width, data_col_width
        row = (row_title + '\t\t').rjust(title_col_width)
        result_groups = iter(results)
        
        next(result_groups)
        for result_group in result_groups:
            row += data_string.format(**data_func(result_group)).ljust(data_col_width)
        print(row)

    def print_random_restart_data(row_title, avg):
        nonlocal title_col_width, data_col_width
        row = (row_title + '\t\t').rjust(title_col_width) + str(avg)
        print(row)


    num_iterations = len(results[0])

    print('\t'.rjust(title_col_width) +
          'SUCCESSES'.ljust(data_col_width) +
          'FAILURE'.ljust(data_col_width))

    print_data_row('\nSUCCESS AND FAILURE RATE:',
                   '{percent:.1%}',
                   lambda x: {'percent': len(x) / num_iterations},
                   results)

    print_random_restart_data('AVERAGE NUMBER OF RE-START :', Avg_restarts)

    print_data_row('AVERAGE NUMBER OF STEPS :',
                   '{mean:.0f}',
                   lambda x: calculate_avg_pathcost(x, 'path_length'),
                   results)


# Returns a results list containing all the possible solutions, successes and failures
def printSolution(problem_set, search_function):
    results = []
    print('FINDING THE SOLUTIOIN ... PLEASE WAIT ...\n')
    for problem_num, problem in enumerate(problem_set):
        result = search_function(problem)
        result['path_length'] = len(result['solution']) - 1
        results.append(result)
    results = [results,
               [result for result in results if result['outcome'] == 'success'],
               [result for result in results if result['outcome'] == 'failure']]

    # Calculate Average number of random restarts
    if 'NoRestarts' in results[0][00]:
        ran_restarts = []
        
        for result in results[0]:
            ran_restarts.append(result['NoRestarts'])
        Avg_restarts = mean(ran_restarts)
        printSolution_random_restartResult(results, Avg_restarts)
    else:
        print_results(results)


# Function calls all the variants of the hill climbing algorithm
def main(queens_state):
    
    print('\nHILL CLIMBING NO SIDEWAYS MOVES ALLOWED PROGRAM STARTED')
    printSolution(queens_state, HillClimbing)

    print('\nRANDOM RESTART HILL CLIMBING NO SIDE WAYS MOVES ALLOWED PROGRAM STARTED:')
    printSolution(queens_state, lambda x: random_restart_hill_climb(queens_state[0].__class__, allow_sideways=False))
     

'''
Main program.
run n queen problem for 500 times
student id = 144214
number of experiments = 100+14=114
please change range for different experiments
'''
queens_state = [QueensProblem() for _ in range(144)]
main(queens_state)
