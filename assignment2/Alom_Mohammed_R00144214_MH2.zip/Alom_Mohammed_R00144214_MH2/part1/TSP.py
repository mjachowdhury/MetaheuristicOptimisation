# -*- coding: utf-8 -*-
"""
Created on Fri Dec 18 18:33:01 2020

@author: mohammed alom
reference : Would like acknowledge this program is created with the help and ideas of
multiple sources- from Dr. Diarmuid Grimes lecture notes, greekforgreek website, stackoveflow.
"""
import os
import time
import random
import itertools
import functools
import numpy as np
import plotly as py
import multiprocessing



class TSP(object):
    def __init__(self, tsp_input_file_path):
        self.tsp_input_file_path = tsp_input_file_path
        self.data = []
        self.random_solution = []
        self.total_cost = 0
        self.distance_mat = None


    def read_instance(self):
        """
        Reading an tsp instance from file path directory
        """
        tsp_input_file = open(self.tsp_input_file_path, 'r').read().splitlines()
        tsp_input_file.pop(0)
        cities = np.array([tuple(map(int, coord.split()[1:])) for coord in tsp_input_file])
        self.data = cities
        #tsp_input_file.close()


    #@functools.lru_cache(maxsize=None)
    '''
     Note as this function gets called many thousands of times, so its memoized the function with lru_cache
     which will prevent this function from running if it has the result already in cache
    '''
    @staticmethod
    def euclidean_distance(city_one, city_two):
        """
        Distance between two cities
        :param city_one: 1st City
        :param city_two: 2nd City
        :return: Euclidean distance between 1st and 2nd  cities
        """
        return np.linalg.norm(city_two-city_one)


    def generate_nearest_neighbour_solution(self):
        """
        Use greedy nearest neighbour algorithm to generate the tour of cities
            1. Pick a random starting point
            2. Find the nearest neighbour to that city
            3. Add that city to the list of visited cities
            4. Remove the chosen city from our list to avoid re-visiting the city

        Generate Nearest Neighbor Solution
        :return: void
        """
        print('\nGENERATING INITIAL NEAREST FIRST IMPROVEMENT')

        cities = self.data.copy().tolist()

        # Choosing random starting point
        random_selected_city = random.randint(0, len(cities) - 1)
        new_route = [cities[random_selected_city]]
        cities.pop(random_selected_city)

        #As long as their cities keep looping through
        #until we found the nearest neighbour
        while len(cities) >= 1:

            last_city = np.array(new_route[-1])
            pending_cities = np.array(cities)
            distances_arr = [self.euclidean_distance(last_city, city_two) for city_two in pending_cities]
            min_dist_idx = np.argmin(distances_arr)
            nearest_city = pending_cities[min_dist_idx].tolist()

            # Append the nearest city to the tour
            new_route.append(nearest_city)

            # remove the current city to avoid re-visiting that city
            cities.remove(nearest_city)

        self.random_solution = new_route
        self.total_cost = self.calculate_tour_cost(new_route)


    def generaet_random_tour_solution(self):
        """
        Generate random initial solution
        Generates a random initial tour solution of all cities ending with the
        same city we started at. Cities can only be visited once and all cities must be visited
        :return: void
        """
        print('\nGENERATING INITIAL RANDOM SOLUTION')

        # Use temporary variable to generate random tour
        copied_data = self.data.copy()
        data_len = copied_data.shape[0]

        for _ in range(data_len):
            n1 = random.randint(0, data_len - 1)
            n2 = random.randint(0, data_len - 1)

            copied_data[[n1,n2]] = copied_data[[n2,n1]]

        self.random_solution = copied_data.tolist()
        self.total_cost = self.calculate_tour_cost(copied_data)


    def calculate_tour_cost(self, cities):
        """
        Calculate sum of euclidean distances between two
        points including the first to last. Compute the cost of the tour
        :param cities: The current tour
        :return: total tour cost
        """
        cities_np_arr = np.array(cities)
        # Initial cost set to zero
        total_cost = 0.0
        # Loop through all the cities edges in the tour adding to the cost
        for i in range(len(cities_np_arr)):
            total_cost += self.euclidean_distance(cities_np_arr[i - 1], cities_np_arr[i])
        
        return total_cost



    def generate_combinations_local_search(self, cities, edge1, edge2, edge3):
        """
        Function to find the best 3-opt combination
        This method generate 8 possible combinations from a list of cities
        :param cities: List of cities
        :param edge1: [a, b]
        :param edge2: [c, d]
        :param edge3: [e, f]
        :return: Best combination i.e. list of cities, tour cost
        
        Finding the best combination of 6 edges from the 8 possible combinations below 
        If a better solution is found, update the currect solution           
        """ 
         
        combination_1 = cities[:edge1[0] + 1] + cities[edge1[1]: edge2[0] + 1]    + cities[edge2[1] : edge3[0] + 1] + cities[edge3[1]: ]
        combination_2 = cities[:edge1[0] + 1] + cities[edge1[1]: edge2[0] + 1]    + cities[edge3[0] : edge2[1] - 1: -1] + cities[edge3[1]: ]
        combination_3 = cities[:edge1[0] + 1] + cities[edge2[0]: edge1[1] - 1: -1] + cities[edge2[1]: edge3[0] + 1] + cities[edge3[1]: ]
        combination_4 = cities[:edge1[0] + 1] + cities[edge2[0]: edge1[1] - 1: -1] + cities[edge3[0]: edge2[1] - 1: -1] + cities[edge3[1]: ]
        combination_5 = cities[:edge1[0] + 1] + cities[edge2[1]: edge3[0] + 1]    + cities[edge1[1] :edge2[0] + 1] + cities[edge3[1]: ]
        combination_6 = cities[:edge1[0] + 1] + cities[edge2[1]: edge3[0] + 1]    + cities[edge2[0] :edge1[1] - 1: -1] + cities[edge3[1]: ]
        combination_7 = cities[:edge1[0] + 1] + cities[edge3[0]: edge2[1] - 1: -1] + cities[edge1[1]:edge2[0] + 1] + cities[edge3[1]: ]
        combination_8 = cities[:edge1[0] + 1] + cities[edge3[0]: edge2[1] - 1: -1] + cities[edge2[0]:edge1[1] - 1: -1] + cities[edge3[1]: ]

        combinations_array = [combination_1, combination_2, combination_3, combination_4, combination_5, combination_6, combination_7, combination_8]
        distances_array = list(map(lambda x: self.calculate_tour_cost(x), combinations_array))
        min_distance = int(np.argmin(distances_array))
        
        return combinations_array[min_distance], distances_array[min_distance]


    def three_opt_search(self, route):
        """
        3 OPT Local search Implementation
        Generates all possible valid combinations.
        Runs a for loop for each combination obtained above and generates 7 different combinations
        possible after 3 OPT move. Selects the one with minimum tour cost
        Find the cities that when swapped produce the greatest cost reduction
        This generates all possible sorted routes and hence eliminating
        the need of for loop and then sorting it and hence avoiding duplicates
        :param route: list of cities
        :return: updated list of cities , tour_cost
        """
        #start_time = time.time()
        all_combinations = list(itertools.combinations(range(len(route)), 3))
 
        # Select any random city including first and last city
        random_city = np.random.randint(low=0, high=len(route))

        # Keep only valid combinations, i.e combinations containing the random selected city
        all_combinations = list(filter(lambda x: random_city in x, all_combinations))

        for idx, item in enumerate(all_combinations):
            #print('EXPERIMENT {0}'.format(idx))

            """
            Run for every combination generated above.
            a,c,e = x,y,z  # Generated in the combination
            d,e,f = x+1, y+1, z+1  # To form the edge
            """
            #print('ITERATOION COUNT : {} AND ITEM A, B, C : {}' .format(idx, item))
            a1, c1, e1 = item
            b1, d1, f1 = a1+1, c1+1, e1+1

            """The above generates the edge. The edge is sent to generate 7 possible combinations and the best one is
            selected and applied to the global solution
            """
            # Check if we have exceeded the configured time limit
            #if (time.time() - start_time) > self.local_search_time_limit:
                #print('EXCEED MAXIMUM TIME FOR SEARCH - RETURNING BEST FOUND VALUE')

            route, new_cost = self.generate_combinations_local_search(route, [a1, b1], [c1, d1], [e1, f1])

        new_cost = self.calculate_tour_cost(route)
        return route, new_cost

    def two_opt_swap_search(self):
        """
        Function to find the best 2-opt combination
        Implementation of the 2-opt algorithm
        - Chose 2 random variables
        - Swap the 2 variables
        - Repeat 5 times. its not a mandatory can be change
        :return: Returns the new route created by 2opt swap i.e. list of cities
        """
        cities = self.random_solution.copy()
        size_of_cities = len(cities)

        #print('\nRUNNING 2-OPT SWAP 5 TIMES')
        for i in range(1):

            #print('EXPERIMENTS {0}'.format(i))
            city_one, city_two = random.randrange(0, size_of_cities), random.randrange(0, size_of_cities)
            exclude = {city_one}
            
            """ Finding the best combination of 2 edges from the 1 possible combination below """
            """ If a better solution is found, update the currect solution """
            exclude.add(size_of_cities - 1) if city_one == 0 else exclude.add(size_of_cities - 1)
            exclude.add(0) if city_one == size_of_cities - 1 else exclude.add(city_one + 1)
            
            while city_two in exclude:
                city_two = random.randrange(0, size_of_cities)

            if city_two < city_one:
                city_one, city_two = city_two, city_one

            assert 0 <= city_one < (size_of_cities - 1)
            assert city_one < city_two < size_of_cities

            cities[city_one:city_two] = reversed(cities[city_one:city_two])

        return cities

    def second_variant(self, best_found):
        """
        Function to decide whether to update solL(s*) or not
        Compares the existing best solution with the solution
        obtained from 2_opt swap and local search.
        Takes a Probability of 0.05 % for best_found otherwise
        compare it with the existing solution
        :param best_found: Best calculated after 2_opt swap and local search
        :return: void
        """
        best_dist = self.calculate_tour_cost(best_found)
        #print('BEST TWO_OPT DISTANCE IS : {}'.format(best_dist))
        #print('BEST SOLUTION IS : {}'.format(self.total_cost))

        if random.random() < 0.05:
            self.random_solution = best_found
            self.total_cost = best_dist
        else:
            if best_dist < self.total_cost:
                self.random_solution = best_found
                self.total_cost = best_dist

    def main(self, initial_solution, tsp_file_name, iteractive_count):
        """
        This is the main function of TSP. Initial solution is generated based
        on value of initial_solution param.
        Runs 3 opt -- local search
        for 5 minutes:
            2 OPT
            local search
            acceptance criteria

        :param initial_solution: random or nearest neighbours
        :param tsp_file_name: Essential for creating graph
        :param iteractive_count: Essential for creating graph
        :return: void
        """
        self.read_instance()
        if initial_solution == "nn":
            self.generate_nearest_neighbour_solution()
        else:
            self.generaet_random_tour_solution()

        """
        Plot Initial Graph all the cities and will be save in the program directory
        """
        print('\nINITIAL COST : {} '.format(self.total_cost))
        visualize_program(self.random_solution, self.total_cost, 'INITIAL_GRAPHS_OF_THE_PROBLEM_{}_{}_{}.html'.format(tsp_file_name, initial_solution, iteractive_count))

        # Start 3 OPT Local Search
        three_opt_search_start_time = time.time()
        route, distance = self.three_opt_search(self.random_solution)
        self.random_solution = route
        self.total_cost = distance
        print('\nTHREE-OPT PROGRAM RUNNING...')
        print('\nTHREE OPT SEARCH COMPLETED IN : {} '.format(time.time() - three_opt_search_start_time), 'SECONDS')

        # Two opt phase
        '''
        Note as this can take a long time to run we apply a time limit to the function.
        When the function exceeds this time limit we will return the best state that we have currently found
        '''
        seconds_to_run = 300 #5 minutes
        counter = itertools.count()
        elapsed_time = time.time()

        print('\nTWO-OPT PROGRAM RUNNING...........')

        while time.time() - elapsed_time < seconds_to_run:
            cities = self.two_opt_swap_search()
            if time.time() - elapsed_time < seconds_to_run:
                best_two_opt_solution, distance = self.three_opt_search(cities)
                self.second_variant(best_two_opt_solution)
                next(counter)

        """
        Final solution Graph will be save in the program directory
        """
        visualize_program(self.random_solution, self.total_cost, 'FINAL_GRAPH_OF_THE_SOLUTION_{}_{}_{}.html'.format(tsp_file_name, initial_solution, iteractive_count))
        print('\nBEST SOLUTION OBTAINED : {} '.format(self.total_cost))


def visualize_program(cities, length_of_route, tsp_file_name):
    """
    Generates TSP Graph using Plotly library
    :param cities: list of cities
    :param length_of_route: Total cost/distance of cities
    :param tsp_file_name: For saving the graph
    :return: void
    """
    cities_arr = np.array(cities)
    cities_arr = np.vstack([cities_arr, cities_arr[0]])

    line = {
      "x": cities_arr[:, 0],
      "y": cities_arr[:, 1],
      "name": 'col2',
      "type": 'scatter',
      "mode": 'lines+markers'
    }
    data = [line]
    layout = {
      "autosize": True,
      "font": {"color": "rgb(61, 133, 198)"},
      "showlegend": True,
      "title": "LENGTH OF THE ROUTE IS : {}".format(length_of_route),
      "titlefont": {"color": "rgb(153, 0, 255)"},
      "xaxis": {
        "autorange": True,
        "title": "",
        "type": "linear"
      },
      "yaxis": {
        "autorange": True,
        "title": "",
        "type": "linear"
      }
    }
    fig = dict(data=data, layout=layout)
    py.offline.plot(fig, filename=tsp_file_name)

def run(iteration_count, ip_file_name):
    """
    For running TSP. This function is responsible for creating an object of
    TSP class and invoking the main function of the object.
    :param iteration_count: Iteration count for creating a log file with exact name
    :param ip_file_name: File Name
    :return: void
    """
    ip_file = os.path.join('dataset', ip_file_name)

    tsp = TSP(ip_file)
    tsp.main('random', 'inst-0.tsp', iteration_count)
    #tsp.main('random', 'inst-13.tsp', iteration_count)
    #tsp.main('random', 'inst-5.tsp', iteration_count)


if __name__ == '__main__':
    """
    We will be using Python multiProcessing to spawn multiple processes to run TSP
    max iteration count is 5. please change the file during the run time.
    """
    tsp_file_name = 'inst-0.tsp'
    #tsp_file_name = 'inst-13.tsp'
    #tsp_file_name = 'inst-5.tsp'
    total_iteration_count = 0
    processes = []
    while total_iteration_count != 1:#for testing purpose just doing once
        t = multiprocessing.Process(target=run, args=(total_iteration_count, tsp_file_name))
        total_iteration_count += 1
        processes.append(t)
        t.start()

    for process in processes:
        process.join()

    print("\nPROGRAM RUNNING FINISHED.")
