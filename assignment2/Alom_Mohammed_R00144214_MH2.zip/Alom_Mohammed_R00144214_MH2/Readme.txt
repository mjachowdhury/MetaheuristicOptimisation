Part 1
------
To run the program, please type on the command prompt 
	python TSP.py

- for part one, a plotly python library is required to visualize the program.
- While running the program, it will display the initial and the final solution on the web browser. The file will also save in the program directory.
- part1 directory has one file TSP.py
- inside the part 1 directory, it has a dataset and results directory.
- to run a different tsp file, please update it on the code on lines 382 and 392.

Part 2
------

 - it has only one file  RTD.py
 - to run the file from the command prompt, just type - python RTD.py